"""API for communication with simulator."""

import enum
import sys


class MouseCrashedError(Exception):
    """Mouse crashed to wall."""

    pass


class Colors(enum.Enum):
    """Supported colors by simulator."""

    BLACK = 'k'
    BLUE = 'b'
    GRAY = 'a'
    CYAN = 'c'
    GREEN = 'g'
    ORANGE = 'o'
    RED = 'r'
    WHITE = 'w'
    YELLOW = 'y'
    DARK_BLUE = 'B'
    DARK_CYAN = 'C'
    DARK_GRAY = 'A'
    DARK_GREEN = 'G'
    DARK_RED = 'R'
    DARK_YELLOW = 'Y'


class Server:
    """Core communication handler."""

    @staticmethod
    def send(*args):
        """Send a command to simulator."""
        cmd = ' '.join(str(x) for x in args) + '\n'
        sys.stdout.write(cmd)
        sys.stdout.flush()

    @staticmethod
    def receive(_as=None):
        """Receive a response from simulator."""
        if _as:
            response = sys.stdin.readline().strip()

            if _as == bool:
                return response == 'true'

            return _as(response)


def mazeWidth():
    Server.send('mazeWidth')
    return Server.receive(int)


def mazeHeight():
    Server.send('mazeHeight')
    return Server.receive(int)


def wallFront():
    Server.send('wallFront')
    return Server.receive(bool)


def wallRight():
    Server.send('wallRight')
    return Server.receive(bool)


def wallLeft():
    Server.send('wallLeft')
    return Server.receive(bool)


def moveForward(distance=None):
    args = ['moveForward']
    # Don't append distance argument unless explicitly specified, for
    # backwards compatibility with older versions of the simulator
    if distance is not None:
        args.append(distance)

    Server.send(*args)
    response = Server.receive(str)

    if response == 'crash':
        raise MouseCrashedError()

    return response


def turnRight():
    Server.send('turnRight')
    return Server.receive(str)


def turnLeft():
    Server.send('turnLeft')
    return Server.receive(str)


def setWall(x, y, direction):
    Server.send('setWall', x, y, direction)


def clearWall(x, y, direction):
    Server.send('clearWall', x, y, direction)


def setColor(x, y, color: Colors):
    Server.send('setColor', x, y, color.value)


def clearColor(x, y):
    Server.send('clearColor', x, y)


def clearAllColor():
    Server.send('clearAllColor')


def setText(x, y, text):
    Server.send('setText', x, y, text)


def clearText(x, y):
    Server.send('clearText', x, y)


def clearAllText():
    Server.send('clearAllText')


def wasReset():
    Server.send('wasReset')
    return Server.receive(bool)


def ackReset():
    Server.send('ackReset')
    return Server.receive(str)

def getStat(stat):
    Server.send(f'getStat {stat}')
    return Server.receive(str)