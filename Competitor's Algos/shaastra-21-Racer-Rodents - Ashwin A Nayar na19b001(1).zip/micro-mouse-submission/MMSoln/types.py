from .bitops import getLSB


class PVector2D:
    def __init__(self, x=0, y=0):
        self.x, self.y = x, y

    def __eq__(self, other) -> bool:
        return self.x == other.x and self.y == other.y

    def __ne__(self, other) -> bool:
        return not self.__eq__(other)

    def __str__(self) -> str:
        return f'({self.x}, {self.y})'


class Perception2D:
    def __init__(self, w0=False, w1=False, w2=False, w3=False):
        self.w0 = w0  # West in global frame, left in ego frame
        self.w1 = w1  # South in global frame, back in ego frame
        self.w2 = w2  # East in global frame, right in ego frame
        self.w3 = w3  # North in global frame, front in ego frame

    @property
    def value(self) -> int:
        return self.w0 << 0 | self.w1 << 1 | self.w2 << 2 | self.w3 << 3

    @value.setter
    def value(self, n: int):
        self.w0 = getLSB(n, 0)
        self.w1 = getLSB(n, 1)
        self.w2 = getLSB(n, 2)
        self.w3 = getLSB(n, 3)
