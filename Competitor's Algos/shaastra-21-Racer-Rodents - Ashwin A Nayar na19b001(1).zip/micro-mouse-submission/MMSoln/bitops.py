def rotl4(value: int, count: int) -> int:
    """4 bit left circular shift."""
    return ((value << count) | (value >> (4 - count))) & 15


def rotr4(value: int, count: int) -> int:
    """4 bit right circular shift."""
    return ((value >> count) | (value << (4 - count))) & 15


def getLSB(n: int, k: int) -> bool:
    """Get LSB of `n` at position `k` (0 based index counted from right)."""
    return bool(n & (1 << k))
