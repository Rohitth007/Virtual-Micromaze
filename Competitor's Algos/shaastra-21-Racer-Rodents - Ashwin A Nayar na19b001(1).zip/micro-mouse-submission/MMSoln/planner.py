from .types import PVector2D, Perception2D
from .tf import PVector2DTransform, Perception2DTransform
from . import API
from .maze import Maze
from .algorithm import floodFill
from collections import deque
import random

import logging

_logger = logging.getLogger(__name__)


class Planner:
    def __init__(self):
        self._mPos = PVector2D(0, 0)
        self._mZZ = 0
        self._maze = Maze()
        self._floodMat = floodFill(self._maze)
        self._visitMatrix = [[False for y in range(16)] for x in range(16)]
        self._shortestPath = deque()

    def explorePreDestn(self):
        _logger.info('Exploration - Phase I')
        while not Maze.isGoal(self._mPos):
            wL, wF, wR = API.wallLeft(), API.wallFront(), API.wallRight()
            tf = PVector2DTransform(self._mPos.x, self._mPos.y, self._mZZ)

            cLeft = tf.l2g(PVector2D(0, -1))
            cFront = tf.l2g(PVector2D(1, 0))
            cRight = tf.l2g(PVector2D(0, 1))

            for cell, isWall in zip([cLeft, cFront, cRight], [wL, wF, wR]):
                if isWall:
                    self._maze.setWall(self._mPos, cell)

            self._floodMat = floodFill(self._maze)

            self.updateSim()

            validNs = []
            for n in self._maze.getNeighbours(self._mPos):
                if n is None:
                    continue
                validNs.append(n)

            validNs.sort(key=lambda n: self._floodMat[n.x][n.y])

            movable = []
            for n in validNs:
                if not self._maze.isAccessible(self._mPos, n):
                    continue
                movable.append(n)

            if len(movable) > 1 and movable[0] == movable[1]:
                self.moveTo(random.choice(movable[:2]))
            else:
                self.moveTo(movable[0])

        if Maze.isGoal(self._mPos):
            _logger.info('Reached destination')

    def processMaze(self):
        for x in range(16):
            for y in range(16):
                cell = PVector2D(x, y)
                for n in Maze.getNeighbours(cell):
                    if n is None:
                        continue
                    if not (self._visitMatrix[cell.x][cell.y] or self._visitMatrix[n.x][n.y]):
                        self._maze.setWall(cell, n)

        self._floodMat = floodFill(self._maze)

    def isSprintRequired(self) -> bool:
        currentScore = float(API.getStat('score'))
        projectedCurrentDistance = len(self._shortestPath) - 1
        projectedCurrentTurns = -1

        flag = 0

        prevPoint = PVector2D(0, 0)
        for cell in self._shortestPath:
            if cell.x == prevPoint.x:
                if flag != 0:
                    projectedCurrentTurns += 1
                flag = 0
            elif cell.y == prevPoint.y:
                if flag != 1:
                    projectedCurrentTurns += 1
                flag = 1
            prevPoint = cell

        _logger.debug(f"Predicted current distance: {projectedCurrentDistance}")
        _logger.debug(f"Predicted current turns: {projectedCurrentTurns}")

        return 9 * (projectedCurrentTurns + projectedCurrentDistance) < currentScore

    def calculateShortestPath(self):
        cell = PVector2D(0, 0)
        f = self._floodMat[0][0]
        while not Maze.isGoal(cell):
            self._shortestPath.append(cell)

            for n in Maze.getNeighbours(cell):
                if n is None or not self._maze.isAccessible(cell, n):
                    continue
                fNew = self._floodMat[n.x][n.y]
                if fNew == f - 1:
                    f = fNew
                    cell = n
                    break
        self._shortestPath.append(cell)
        _logger.info('Calculated shortest path')

    def getBackToStart(self):
        assert len(self._shortestPath) != 0

        for cell in reversed(self._shortestPath):
            self.moveTo(cell)
    
    def goToGoal(self):
        for cell in self._shortestPath:
            self.moveTo(cell)

    def updateSim(self):
        for x in range(16):
            for y in range(16):
                cell = PVector2D(x, y)
                north = PVector2D(x + 1, y)
                east = PVector2D(x, y + 1)
                south = PVector2D(x - 1, y)
                west = PVector2D(x, y - 1)

                if not self._maze.isAccessible(cell, north):
                    API.setWall(cell.y, cell.x, 'n')
                if not self._maze.isAccessible(cell, east):
                    API.setWall(cell.y, cell.x, 'e')
                if not self._maze.isAccessible(cell, south):
                    API.setWall(cell.y, cell.x, 's')
                if not self._maze.isAccessible(cell, west):
                    API.setWall(cell.y, cell.x, 'w')

                API.setText(y, x, self._floodMat[x][y])

    def moveTo(self, cell: PVector2D):
        if cell == self._mPos:
            return
        tf = PVector2DTransform(self._mPos.x, self._mPos.y, self._mZZ)
        lCell = tf.g2l(cell)
        self._visitMatrix[cell.x][cell.y] = True
        if lCell.y == 0:
            if lCell.x == 1:
                self._moveForward()
                return
            if lCell.x == -1:
                self._turnRight()
                self._turnRight()
                self._moveForward()
                return
        if lCell.x == 0:
            if lCell.y == 1:
                self._turnRight()
                self._moveForward()
                return
            if lCell.y == -1:
                self._turnLeft()
                self._moveForward()
                return

        _logger.error(f'Cannot move to {str(cell)}')

    def _moveForward(self):
        API.moveForward()
        tf = PVector2DTransform(self._mPos.x, self._mPos.y, self._mZZ)
        self._mPos = tf.l2g(PVector2D(1, 0))

    def _turnLeft(self):
        API.turnLeft()
        self._mZZ -= 90

    def _turnRight(self):
        API.turnRight()
        self._mZZ += 90
