from .maze import Maze
from collections import deque
from .types import PVector2D


def floodFill(maze: Maze):
    visited = [[False for y in range(16)] for x in range(16)]
    floodMatrix = [[0 for y in range(16)] for x in range(16)]

    for x in range(16):
        for y in range(16):
            floodMatrix[x][y] += abs(x - (x // 8 + 7))
            floodMatrix[x][y] += abs(y - (y // 8 + 7))

    queue = deque()

    for cell in Maze.DESTINATIONS:
        visited[cell.x][cell.y] = True
        queue.append(PVector2D(cell.x, cell.y))

    while len(queue) != 0:
        cell = queue.popleft()

        x, y, f = cell.x, cell.y, floodMatrix[cell.x][cell.y]

        for n in Maze.getNeighbours(cell):
            if n is None:
                continue

            if not visited[n.x][n.y] and maze.isAccessible(cell, n):
                floodMatrix[n.x][n.y] = f + 1
                queue.append(n)
                visited[n.x][n.y] = True

    return floodMatrix
