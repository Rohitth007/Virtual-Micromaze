import abc
import numpy as np
from .types import PVector2D, Perception2D
from .bitops import rotl4, rotr4

import logging

_logger = logging.getLogger(__name__)


class AbstractTransform(metaclass=abc.ABCMeta):

    @abc.abstractmethod
    def l2g(self, lObj):
        raise NotImplementedError

    @abc.abstractmethod
    def g2l(self, gObj):
        raise NotImplementedError


class PVector2DTransform(AbstractTransform):

    def __init__(self, x: int, y: int, theta: float):
        self._x, self._y = x, y
        self._theta = np.deg2rad(theta)

    def l2g(self, lPVec: PVector2D) -> Perception2D:
        _logger.debug('Request for PVector2D transform local -> global')
        rotMatrix = np.array([
            [np.cos(self._theta), np.sin(self._theta)],
            [-np.sin(self._theta), np.cos(self._theta)]
        ])
        rotated = np.dot(np.array([lPVec.x, lPVec.y]), rotMatrix)
        gPVec = PVector2D()
        gPVec.x, gPVec.y = map(int, np.rint(np.add(rotated, np.array([self._x, self._y]))))

        return gPVec

    def g2l(self, gPVec: PVector2D) -> Perception2D:
        _logger.debug('Request for PVector2D transform global -> local')
        rotMatrix = np.array([
            [np.cos(self._theta), -np.sin(self._theta)],
            [np.sin(self._theta), np.cos(self._theta)]
        ])
        translated = np.subtract(np.array([gPVec.x, gPVec.y]), np.array([self._x, self._y]))
        lPVec = PVector2D()
        lPVec.x, lPVec.y = map(int, np.rint(np.dot(translated, rotMatrix)))

        return lPVec


class Perception2DTransform(AbstractTransform):

    def __init__(self, x, y, theta):
        self._x, self._y = x, y
        self._theta = theta

    def l2g(self, lPerc: Perception2D) -> Perception2D:
        _logger.debug('Request for Perception2D transform local -> global')
        gPerc = Perception2D()

        n = (self.theta % 360) // 90
        gPerc.value = rotr4(lPerc.value, n)

        return gPerc

    def g2l(self, gPerc: Perception2D) -> Perception2D:
        _logger.debug('Request for Perception2D transform global -> local')
        lPerc = Perception2D()

        n = (self.theta % 360) // 90
        lPerc.value = rotl4(gPerc.value, n)

        return lPerc
