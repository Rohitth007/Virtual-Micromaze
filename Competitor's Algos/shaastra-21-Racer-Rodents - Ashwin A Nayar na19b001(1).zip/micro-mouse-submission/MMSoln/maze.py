import logging
from .types import PVector2D

_logger = logging.getLogger(__name__)


class Maze:

    DESTINATIONS = [
        PVector2D(7, 7),
        PVector2D(7, 8),
        PVector2D(8, 7),
        PVector2D(8, 8)
    ]

    def __init__(self):
        self._adjMat = [[0 for x in range(256)] for y in range(256)]

    def setWall(self, c1: PVector2D, c2: PVector2D):
        if not (Maze.isValid(c1) and Maze.isValid(c2)):
            return
        i = Maze.coords2index(c1.x, c1.y)
        j = Maze.coords2index(c2.x, c2.y)
        self._adjMat[i][j] = 1
        self._adjMat[j][i] = 1

        _logger.debug(f'Wall set between {str(c1)} and {str(c2)}')

    def isAccessible(self, c1: PVector2D, c2: PVector2D):
        if not (Maze.isValid(c1) and Maze.isValid(c2)):
            return False
        i = Maze.coords2index(c1.x, c1.y)
        j = Maze.coords2index(c2.x, c2.y)
        return self._adjMat[i][j] == 0

    @staticmethod
    def getNeighbours(cell: PVector2D):
        north = PVector2D(cell.x + 1, cell.y)
        if not Maze.isValid(north):
            north = None
        
        east = PVector2D(cell.x, cell.y + 1)
        if not Maze.isValid(east):
            east = None
        
        south = PVector2D(cell.x - 1, cell.y)
        if not Maze.isValid(south):
            south = None
        
        west = PVector2D(cell.x, cell.y - 1)
        if not Maze.isValid(west):
            west = None
        
        return north, east, south, west

    @staticmethod
    def isValid(cell: PVector2D) -> bool:
        if cell.x < 0 or cell.x > 15:
            return False
        if cell.y < 0 or cell.y > 15:
            return False
        return True

    @staticmethod
    def isGoal(cell: PVector2D) -> bool:
        return cell in Maze.DESTINATIONS

    @staticmethod
    def coords2index(x, y):
        if x < 0 or x > 15 or y < 0 or y > 15:
            _logger.warning(f"Invalid conversion request (coordinates -> index). Got ({x}, {y})")
        return 16 * x + y

    @staticmethod
    def index2coords(idx):
        if idx < 0 or idx > 255:
            _logger.warning(f"Invalid conversion request (index -> coordinates). Got ({idx})")
        return divmod(idx, 16)
