# Submission - Team Racer Rodents | SHAASTRA 2020-21

# Online Micro Mouse Maze

## Build/Run requirements

- Targeted OS: **Linux**

- Python version >= **3.6**

- Install python library dependencies

```bash
python3 -m pip install -r requirements.txt
```

## Simulator configuration

```
Name : Team Racer Rodents
Directory: <path-to-source-code-directory>
Build Command: 
Run Command: python3 main.py
```

## Team details

- Members

| Member         | Shaastra ID | Phone no   | Email                     | College    |
| -------------- | ----------- | ---------- | ------------------------- | ---------- |
| Harshin N      | SHA00235    | 7356793830 | me19b109@smail.iitm.ac.in | IIT Madras |
| Ashwin A Nayar | SHA00416    | 7907294821 | na19b001@smail.iitm.ac.in | IIT Madras |
