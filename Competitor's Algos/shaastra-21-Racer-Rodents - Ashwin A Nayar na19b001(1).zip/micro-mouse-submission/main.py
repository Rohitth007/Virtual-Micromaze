from MMSoln.planner import Planner
import logging
import sys
from MMSoln import API

LOG_FMT = '%(asctime)s | %(levelname)-5s | %(filename)-10s:%(lineno)d | %(message)s'

logging.basicConfig(
    stream=sys.stderr,
    level=logging.INFO,
    format=LOG_FMT
)

_logger = logging.getLogger(__name__)

def printStatistics():
    print(f"Total distance: {API.getStat('total-distance')}", file=sys.stderr)
    print(f"Total turns: {API.getStat('total-turns')}", file=sys.stderr)
    print(f"Current run distance: {API.getStat('current-run-distance')}", file=sys.stderr)
    print(f"Current run turns: {API.getStat('current-run-turns')}", file=sys.stderr)
    print(f"Score: {API.getStat('score')}", file=sys.stderr)

_logger.info("Firing up")

p = Planner()
p.explorePreDestn()
p.processMaze()
# p.updateSim()
p.calculateShortestPath()
if p.isSprintRequired():
    p.getBackToStart()
    p.goToGoal()
else:
    _logger.info("Skipping fast run, score expected to increase!")
_logger.info('Shutdown')
