#include <iostream>
#include <bits/stdc++.h>
#include "API.h"

using namespace std;

#define int long long
#define float double

#define U 1
#define D -1
#define R 2
#define L -2

void log(const string &text)
{
    cerr << text << endl;
}

int32_t main(void)
{
    log("Running...");

    pair <int, int> coords;

    int direction = U;

    coords.first = 0;
    coords.second = 0;

    int a[16][16] {0};

    a[0][0]++;

    while (true)
    {
        if (API::wallFront() && API::wallRight() && API::wallLeft())
        {
            API::turnRight();
            API::turnRight();
            API::moveForward();

            direction *= -1; 

            if (direction == U)
            {
                coords.second++;
            }
            else if (direction == D)
            {
                coords.second--;
            }
            else if (direction == R)
            {
                coords.first++;
            }
            else if (direction == L)
            {
                coords.first--;
            }

            a[coords.first][coords.second]++;
        }
        else if (!(API::wallLeft()) && !(API::wallRight()) && (API::wallFront()))
        {
            if (direction == U)
            {
                if (a[coords.first - 1][coords.second] > a[coords.first + 1][coords.second])
                {
                    API::turnRight();
                    direction = R;
                    API::moveForward();
                    a[coords.first + 1][coords.second]++;
                    coords.first++;
                }
                else if (a[coords.first + 1][coords.second] > a[coords.first - 1][coords.second])
                {
                    API::turnLeft();
                    direction = L;
                    API::moveForward();
                    a[coords.first - 1][coords.second]++;
                    coords.first--;
                }
                else if (coords.first < 8)
                {
                    API::turnRight();
                    direction = R;
                    API::moveForward();
                    a[coords.first + 1][coords.second]++;
                    coords.first++;
                }
                else
                {
                    API::turnLeft();
                    direction = L;
                    API::moveForward();
                    a[coords.first - 1][coords.second]++;
                    coords.first--;
                }
            }
            else if (direction == D)
            {
                if (a[coords.first + 1][coords.second] > a[coords.first - 1][coords.second])
                {
                    API::turnRight();
                    direction = L;
                    API::moveForward();
                    a[coords.first - 1][coords.second]++;
                    coords.first--;
                }
                else if (a[coords.first + 1][coords.second] < a[coords.first - 1][coords.second])
                {
                    API::turnLeft();
                    direction = R;
                    API::moveForward();
                    a[coords.first + 1][coords.second]++;
                    coords.first++;
                }
                else if (coords.first > 7)
                {
                    API::turnRight();
                    direction = L;
                    API::moveForward();
                    a[coords.first - 1][coords.second]++;
                    coords.first--;
                }
                else
                {
                    API::turnLeft();
                    direction = R;
                    API::moveForward();
                    a[coords.first + 1][coords.second]++;
                    coords.first++;
                }
            }
            else if (direction == R)
            {
                if (a[coords.first][coords.second + 1] > a[coords.first][coords.second - 1])
                {
                    API::turnRight();
                    direction = D;
                    API::moveForward();
                    a[coords.first][coords.second - 1]++;
                    coords.second--;
                }
                else if (a[coords.first][coords.second + 1] < a[coords.first][coords.second - 1])
                {
                    API::turnLeft();
                    direction = U;
                    API::moveForward();
                    a[coords.first][coords.second + 1]++;
                    coords.second++;
                }
                else if (coords.second > 7)
                {
                    API::turnRight();
                    direction = D;
                    API::moveForward();
                    a[coords.first][coords.second - 1]++;
                    coords.second--;
                }
                else
                {
                    API::turnLeft();
                    direction = U;
                    API::moveForward();
                    a[coords.first][coords.second + 1]++;
                    coords.second++;
                }
            }
            else if (direction == L)
            {
                if (a[coords.first][coords.second + 1] < a[coords.first][coords.second - 1])
                {
                    API::turnRight();
                    direction = U;
                    API::moveForward();
                    a[coords.first][coords.second + 1]++;
                    coords.second++;
                }
                else if (a[coords.first][coords.second + 1] > a[coords.first][coords.second - 1])
                {
                    API::turnLeft();
                    direction = D;
                    API::moveForward();
                    a[coords.first][coords.second - 1]++;
                    coords.second--;
                }
                else if (coords.second < 8)
                {
                    API::turnRight();
                    direction = U;
                    API::moveForward();
                    a[coords.first][coords.second + 1]++;
                    coords.second++;
                }
                else
                {
                    API::turnLeft();
                    direction = D;
                    API::moveForward();
                    a[coords.first][coords.second - 1]++;
                    coords.second--;
                }
            }
        }
        else if ((API::wallLeft()) && (API::wallRight()) && !(API::wallFront()))
        {
            API::moveForward();

            if (direction == U)
            {
                coords.second++;
            }
            else if (direction == D)
            {
                coords.second--;
            }
            else if (direction == R)
            {
                coords.first++;
            }
            else
            {
                coords.first--;
            }

            a[coords.first][coords.second]++;
        }
        else if ((API::wallRight()) && !(API::wallFront()) && !(API::wallLeft()))
        {
            if (direction == U)
            {
                if (a[coords.first - 1][coords.second] > a[coords.first][coords.second + 1])
                {
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first - 1][coords.second] < a[coords.first][coords.second + 1])
                {
                    API::turnLeft();
                    direction = L;
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else if (coords.first > 8)
                {
                    API::turnLeft();
                    direction = L;
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == D)
            {
                if (a[coords.first + 1][coords.second] > a[coords.first][coords.second - 1])
                {
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first + 1][coords.second] < a[coords.first][coords.second - 1])
                {
                    API::turnLeft();
                    direction = R;
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else if (coords.first < 7)
                {
                    API::turnLeft();
                    direction = R;
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == R)
            {
                if (a[coords.first][coords.second + 1] > a[coords.first + 1][coords.second])
                {
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first][coords.second + 1] < a[coords.first + 1][coords.second])
                {
                    API::turnLeft();
                    direction = U;
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else if (coords.second < 7)
                {
                    API::turnLeft();
                    direction = U;
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == L)
            {
                if (a[coords.first][coords.second - 1] > a[coords.first - 1][coords.second])
                {
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first][coords.second - 1] < a[coords.first - 1][coords.second])
                {
                    API::turnLeft();
                    direction = D;
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else if (coords.second > 8)
                {
                    API::turnLeft();
                    direction = D;
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
            }
        }
        else if (!(API::wallRight()) && !(API::wallFront()) && (API::wallLeft()))
        {
            if (direction == U)
            {
                if (a[coords.first + 1][coords.second] > a[coords.first][coords.second + 1])
                {
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first + 1][coords.second] < a[coords.first][coords.second + 1])
                {
                    API::turnRight();
                    direction = R;
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else if (coords.first < 8)
                {
                    API::turnRight();
                    direction = R;
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == D)
            {
                if (a[coords.first - 1][coords.second] > a[coords.first][coords.second - 1])
                {
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first - 1][coords.second] < a[coords.first][coords.second - 1])
                {
                    API::turnRight();
                    direction = L;
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else if (coords.first > 8)
                {
                    API::turnRight();
                    direction = L;
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == R)
            {
                if (a[coords.first][coords.second - 1] > a[coords.first + 1][coords.second])
                {
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first][coords.second - 1] < a[coords.first + 1][coords.second])
                {
                    API::turnRight();
                    direction = D;
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else if (coords.second > 8)
                {
                    API::turnRight();
                    direction = D;
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == L)
            {
                if (a[coords.first][coords.second + 1] > a[coords.first - 1][coords.second])
                {
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first][coords.second + 1] < a[coords.first - 1][coords.second])
                {
                    API::turnRight();
                    direction = U;
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else if (coords.second < 7)
                {
                    API::turnRight();
                    direction = U;
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
            }
        }
        else if ((API::wallFront()) && (API::wallRight()) && !(API::wallLeft()))
        {
            if (direction == U)
            {
                API::turnLeft();
                direction = L;
                API::moveForward();
                coords.first--;
                a[coords.first][coords.second]++;
            }
            else if (direction == D)
            {
                API::turnLeft();
                direction = R;
                API::moveForward();
                coords.first++;
                a[coords.first][coords.second]++;
            }
            else if (direction == R)
            {
                API::turnLeft();
                direction = U;
                API::moveForward();
                coords.second++;
                a[coords.first][coords.second]++;
            }
            else if (direction == L)
            {
                API::turnLeft();
                direction = D;
                API::moveForward();
                coords.second--;
                a[coords.first][coords.second]++;
            }
        }
        else if ((API::wallFront()) && !(API::wallRight()) && (API::wallLeft()))
        {
            if (direction == U)
            {
                API::turnRight();
                direction = R;
                API::moveForward();
                coords.first++;
                a[coords.first][coords.second]++;
            }
            else if (direction == D)
            {
                API::turnRight();
                direction = L;
                API::moveForward();
                coords.first--;
                a[coords.first][coords.second]++;
            }
            else if (direction == R)
            {
                API::turnRight();
                direction = D;
                API::moveForward();
                coords.second--;
                a[coords.first][coords.second]++;
            }
            else if (direction == L)
            {
                API::turnRight();
                direction = U;
                API::moveForward();
                coords.second++;
                a[coords.first][coords.second]++;
            }
        }
        else if (!(API::wallLeft()) && !(API::wallRight()) && !(API::wallFront()))
        {
            if (direction == U)
            {
                if (a[coords.first][coords.second + 1] < a[coords.first + 1][coords.second] && a[coords.first][coords.second + 1] < a[coords.first - 1][coords.second])
                {
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first + 1][coords.second] == a[coords.first - 1][coords.second])
                {
                    if (coords.first < 8)
                    {
                        API::turnRight();
                        direction = R;
                        API::moveForward();
                        coords.first++;
                        a[coords.first][coords.second]++;
                    }
                    else
                    {
                        API::turnLeft();
                        direction = L;
                        API::moveForward();
                        coords.first--;
                        a[coords.first][coords.second]++;
                    }
                }
                else if (a[coords.first + 1][coords.second] < a[coords.first - 1][coords.second])
                {
                    API::turnRight();
                    direction = R;
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first + 1][coords.second] > a[coords.first - 1][coords.second])
                {
                    API::turnLeft();
                    direction = L;
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == D)
            {
                if (a[coords.first][coords.second - 1] < a[coords.first + 1][coords.second] && a[coords.first][coords.second - 1] < a[coords.first - 1][coords.second])
                {
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first + 1][coords.second] == a[coords.first - 1][coords.second])
                {
                    if (coords.first < 8)
                    {
                        API::turnLeft();
                        direction = R;
                        API::moveForward();
                        coords.first++;
                        a[coords.first][coords.second]++;
                    }
                    else
                    {
                        API::turnRight();
                        direction = L;
                        API::moveForward();
                        coords.first--;
                        a[coords.first][coords.second]++;
                    }
                }
                else if (a[coords.first + 1][coords.second] < a[coords.first - 1][coords.second])
                {
                    API::turnLeft();
                    direction = R;
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first + 1][coords.second] > a[coords.first - 1][coords.second])
                {
                    API::turnRight();
                    direction = L;
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == R)
            {
                if (a[coords.first + 1][coords.second] < a[coords.first][coords.second + 1] && a[coords.first + 1][coords.second] < a[coords.first][coords.second - 1])
                {
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first][coords.second + 1] == a[coords.first][coords.second - 1])
                {
                    if (coords.second > 7)
                    {
                        API::turnRight();
                        direction = D;
                        API::moveForward();
                        coords.second--;
                        a[coords.first][coords.second]++;
                    }
                    else
                    {
                        API::turnLeft();
                        direction = U;
                        API::moveForward();
                        coords.second++;
                        a[coords.first][coords.second]++;
                    }
                }
                else if (a[coords.first][coords.second - 1] < a[coords.first][coords.second + 1])
                {
                    API::turnRight();
                    direction = D;
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first][coords.second - 1] > a[coords.first][coords.second + 1])
                {
                    API::turnLeft();
                    direction = U;
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.first++;
                    a[coords.first][coords.second]++;
                }
            }
            else if (direction == L)
            {
                if (a[coords.first - 1][coords.second] < a[coords.first][coords.second + 1] && a[coords.first - 1][coords.second] < a[coords.first][coords.second - 1])
                {
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first][coords.second + 1] == a[coords.first][coords.second - 1])
                {
                    if (coords.second < 8)
                    {
                        API::turnRight();
                        direction = U;
                        API::moveForward();
                        coords.second++;
                        a[coords.first][coords.second]++;
                    }
                    else
                    {
                        API::turnLeft();
                        direction = D;
                        API::moveForward();
                        coords.second--;
                        a[coords.first][coords.second]++;
                    }
                }
                else if (a[coords.first][coords.second - 1] > a[coords.first][coords.second + 1])
                {
                    API::turnRight();
                    direction = U;
                    API::moveForward();
                    coords.second++;
                    a[coords.first][coords.second]++;
                }
                else if (a[coords.first][coords.second - 1] < a[coords.first][coords.second + 1])
                {
                    API::turnLeft();
                    direction = D;
                    API::moveForward();
                    coords.second--;
                    a[coords.first][coords.second]++;
                }
                else
                {
                    API::moveForward();
                    coords.first--;
                    a[coords.first][coords.second]++;
                }
            }
        }
    }
}