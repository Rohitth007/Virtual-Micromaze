import numpy as np
from math import sqrt,inf
#import matplotlib.pylab as plt
import sys
import API
import random


block = np.dtype([('heuristic',np.int32),('count',np.int32),('orientation',np.int32)])

def log(string):
    sys.stderr.write("{}\n".format(string))
    sys.stderr.flush()

def showcount():
    log(str(heuristic_map['count']))
def heuristicShow():
    for x in range(16):
        for y in range(16):
            API.setText(x,y,str(heuristic_map[y][x]['heuristic']))
            

#values

wall_flag = [False,False,False]
#initial pose
robot_pose = [0,15]
orientation = ["north","east","south","west"]
orientation_index = 0

def orient_update(turn):
    global orientation_index
    if(turn == 'L'):
        orientation_index = (orientation_index - 1) % 4 
    else:
        orientation_index = (orientation_index + 1) % 4
    log(orientation[orientation_index])

#helper function
def pose_update():
    #left = 0, straight = 1, right = 2
    if(orientation_index == 0):
        robot_pose[1] = robot_pose[1] - 1
    elif(orientation_index == 1):
        robot_pose[0] = robot_pose[0] + 1
    elif(orientation_index == 2):
        robot_pose[1] = robot_pose[1] + 1
    else:
        robot_pose[0] = robot_pose[0] - 1
    heuristic_map[robot_pose[1],robot_pose[0]]['count'] = heuristic_map[robot_pose[1],robot_pose[0]]['count'] + 1
    log("pose updates!!")

def MoveLeft():
    API.turnLeft()
    orient_update('L')
    API.moveForward()
    pose_update()

def MoveRight():
    API.turnRight()
    orient_update('R')
    API.moveForward()
    pose_update()


def wall_checker():
    if(API.wallLeft()):
        wall_flag[0] = True
    else:
        wall_flag[0] = False
    if(API.wallFront()):
        wall_flag[1] = True
    else:
        wall_flag[1] = False
    if(API.wallRight()):
        wall_flag[2] = True
    else:
        wall_flag[2] = False
    log(str(wall_flag))

def oneway(count = 1):
    log(str("running oneway"))
    while(sum(wall_flag) == 2):
        if(not wall_flag[1]):
            API.moveForward()
            pose_update()
        elif(not wall_flag[0]):
            MoveLeft()
        else:
            MoveRight()
        wall_checker()
        if(count == 200 and sum(wall_flag)>1 ):
            heuristic_map[robot_pose[1],robot_pose[0]]['count'] = 200
        # log(str(robot_pose))
    # API.moveForward()
    # pose_update()
    # log(str(robot_pose))
 
def retrieve_huerestic(turn):
    #TURN , ORIENTATION
    adj_cell = robot_pose.copy()
    # log(str("robo_pose:" + str(robot_pose)))
    if(turn == 'L'):
        temp = (orientation_index - 1) % 4
    elif(turn == 'R'):
        temp = (orientation_index + 1) % 4
    else:
        temp = orientation_index

    if(temp == 0):
        adj_cell[1] = robot_pose[1] - 1
    elif(temp == 1):
        adj_cell[0] = robot_pose[0] + 1
    elif(temp == 2):
        adj_cell[1] = robot_pose[1] + 1
    else:
        adj_cell[0] = robot_pose[0] - 1
    # log(str("adj_cell" + str(adj_cell)))

    return heuristic_map[adj_cell[1],adj_cell[0]]['heuristic'],heuristic_map[adj_cell[1],adj_cell[0]]['count']


def dir_choose():
    log(str("choosing direction"))
    candidates = [[inf,inf,inf],[inf,inf,inf]]
    if(sum(wall_flag) < 2):
        if(not wall_flag[0]):
            candidates[0][0], candidates[1][0] =  retrieve_huerestic('L')
        if(not wall_flag[2]):
            candidates[0][2], candidates[1][2] = retrieve_huerestic('R')
        if(not wall_flag[1]):
            candidates[0][1], candidates[1][1] = retrieve_huerestic('C')
        log(str(candidates))
        # if(candidates[1][1]==200):
        #     API.turnRight()
        #     orient_update('R')
        #     API.turnRight()
        #     orient_update('R')
        #     return
        min_count = min(candidates[1])
        indices = [i for i, x in enumerate(candidates[1]) if x == min_count]
        min_heuristic = 20
        for i in indices:
            if(candidates[0][i] < min_heuristic):
                min_heuristic = candidates[0][i]
        indices_h = [i for i, x in enumerate(candidates[0]) if x == min_heuristic]
        index_list = list(set(indices) & set(indices_h))
        choice = random.choice(index_list)
        log(str(indices))
        log(str(indices_h))
        log(str(index_list))
        log(str(choice))
        #choice 0 is left, 1 is straight, 2 is right
        if(not choice):
            API.turnLeft()
            orient_update('L')
        elif(choice == 2):
            API.turnRight()
            orient_update('R')
        API.moveForward()
        pose_update()



def dead_end_mark():
    while(wall_flag[1]):
        API.turnRight()
        orient_update('R')
        heuristic_map[robot_pose[1],robot_pose[0]]['count'] = 200
        wall_checker()
    oneway(200)
        

""" flood=[[14,13,12,11,10,9,8,7,7,8,9,10,11,12,13,14],
        [13,12,11,10,9,8,7,6,6,7,8,9,10,11,12,13],
        [12,11,10,9,8,7,6,5,5,6,7,8,9,10,11,12],
        [11,10,9,8,7,6,5,4,4,5,6,7,8,9,10,11],
        [10,9,8,7,6,5,4,3,3,4,5,6,7,8,9,10],
        [9,8,7,6,5,4,3,2,2,3,4,5,6,7,8,9],
        [8,7,6,5,4,3,2,1,1,2,3,4,5,6,7,8],
        [7,6,5,4,3,2,1,0,0,1,2,3,4,5,6,7],
        [7,6,5,4,3,2,1,0,0,1,2,3,4,5,6,7],
        [8,7,6,5,4,3,2,1,1,2,3,4,5,6,7,8],
        [9,8,7,6,5,4,3,2,2,3,4,5,6,7,8,9],
        [10,9,8,7,6,5,4,3,3,4,5,6,7,8,9,10],
        [11,10,9,8,7,6,5,4,4,5,6,7,8,9,10,11],
        [12,11,10,9,8,7,6,5,5,6,7,8,9,10,11,12],
        [13,12,11,10,9,8,7,6,6,7,8,9,10,11,12,13],
        [14,13,12,11,10,9,8,7,7,8,9,10,11,12,13,14]] """

# class Cell:
#     def __init__(self, heuristic, count, action_space):
#         self.heuristic = 0
#         self.count = 0
#         self.action_space = 0
#     # def __str__(self):
#     #     return str(self.heuristic)

    
heuristic_map = np.empty((16,16),dtype=block)
# print(heuristic_map.shape)

def euclidean_distance(x,y):
    return (sqrt((x-7.5)**2 + (y-7.5)**2))
    # return abs(x-8.5) +abs(y-8.5)

def heurestic_assign():
    for x in range(0,16):
        for y in range(0,16):
            # heuristic_map = (flood[x][y],0,0)

            heuristic_map[x,y] = (euclidean_distance(x,y),0,0)
            print(heuristic_map[x,y])
            print((euclidean_distance(x,y),0,0))
            
heurestic_assign()
heuristic_map[15,0]['count'] = 1
heuristicShow()
# print(heuristic_map['heuristic'])

# fig = plt.figure()
# plt.imshow(heuristic_map['heuristic'], interpolation='nearest')
# plt.show()
# log(str(robot_pose))
# wall_checker()
# oneway()
# wall_checker()
# dir_choose()
# # oneway()
# log(str(heuristic_map['count']))
# log(str(heuristic_map['heuristic']))

def main():
    while (robot_pose != [7,8] and robot_pose != [8,8] and robot_pose != [8,7] and robot_pose != [7,7]):
        wall_checker()
        log(str(robot_pose))
        showcount()
        if(sum(wall_flag) == 3):
            dead_end_mark()
        elif(sum(wall_flag) == 2):
            oneway()
        else:
            dir_choose()
            
            

main()
